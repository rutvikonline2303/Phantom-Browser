/**
 * Phantom Browser - Enhanced CNAME Resolver
 * Advanced DNS-over-HTTPS uncloaking for first-party tracker detection
 *
 * Features:
 * - Multi-provider DoH with fallback
 * - Batch resolution for efficiency
 * - Extended tracker domain detection
 * - Real-time subdomain scanning
 * - Recursive CNAME chain resolution
 */
interface ResolutionResult {
    hostname: string;
    cname: string | null;
    cnameChain: string[];
    isTracker: boolean;
    matchedTracker: string | null;
}
export declare class CNAMEResolver {
    private static DOH_PROVIDERS;
    private static DEFAULT_CACHE_TTL_MS;
    private static MAX_CNAME_CHAIN_DEPTH;
    private static BATCH_DELAY_MS;
    private cache;
    private pendingResolutions;
    private currentProviderIndex;
    private providerFailures;
    private resolvedTrackers;
    constructor();
    /**
     * Check if subdomain is CNAME-cloaked to a tracker
     * Returns the tracker CNAME if detected, null otherwise
     */
    checkAndBlock(hostname: string): Promise<string | null>;
    /**
     * Resolve a hostname with full CNAME chain analysis
     */
    resolve(hostname: string): Promise<ResolutionResult>;
    /**
     * Batch resolve multiple hostnames (for efficiency)
     */
    batchResolve(hostnames: string[]): Promise<ResolutionResult[]>;
    private doResolve;
    /**
     * Query CNAME from DoH providers with fallback
     */
    private queryCNAME;
    /**
     * Match CNAME against known tracker domains
     */
    private matchTrackerDomain;
    /**
     * Add custom tracker domain at runtime
     */
    addTrackerDomain(domain: string): void;
    private getFromCache;
    private addToCache;
    /**
     * Clear expired cache entries
     */
    pruneCache(): number;
    /**
     * Clear entire cache
     */
    clearCache(): void;
    /**
     * Get resolver statistics
     */
    getStats(): {
        cacheSize: number;
        trackersDetected: number;
        activeProvider: string;
        providerHealth: Array<{
            name: string;
            failures: number;
        }>;
        uniqueTrackers: string[];
    };
    /**
     * Get all detected tracker hostnames
     */
    getDetectedTrackers(): string[];
    /**
     * Check if hostname was already detected as tracker
     */
    wasDetectedAsTracker(hostname: string): boolean;
    private delay;
}
export {};
