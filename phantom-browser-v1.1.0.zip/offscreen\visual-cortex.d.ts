/**
 * Phantom Browser - Visual Cortex Module
 * AI-powered visual ad detection using TensorFlow.js
 *
 * Phase 4 - Weeks 13-14:
 * - Week 13: TensorFlow.js setup and environment optimization
 * - Week 14: COCO-SSD model for sponsored label detection
 */
interface DetectionResult {
    bbox: [number, number, number, number];
    class: string;
    score: number;
}
interface AnalysisResult {
    isAd: boolean;
    confidence: number;
    detections: DetectionResult[];
    sponsorLabels: DetectionResult[];
    processingTime: number;
}
interface ModelConfig {
    modelUrl?: string;
    maxDetections: number;
    scoreThreshold: number;
}
export declare class VisualCortex {
    private model;
    private isLoading;
    private modelLoaded;
    private config;
    private analysisCount;
    private adsDetected;
    constructor(config?: Partial<ModelConfig>);
    /**
     * Load TensorFlow.js and COCO-SSD model
     * Called lazily when first analysis is requested
     */
    loadModel(): Promise<boolean>;
    /**
     * Mock model for development (replace with real COCO-SSD in production)
     */
    private createMockModel;
    /**
     * Analyze a video frame or image for ads
     */
    analyzeFrame(imageData: ImageData): Promise<AnalysisResult>;
    /**
     * Run COCO-SSD object detection
     */
    private runObjectDetection;
    /**
     * Detect sponsor labels using pixel analysis
     */
    private detectSponsorLabels;
    /**
     * Check for high contrast region (text on solid background)
     */
    private hasHighContrastRegion;
    /**
     * Check for yellow/orange badge colors (common for "AD" labels)
     */
    private hasAdBadgeColors;
    /**
     * Check for skip button pattern (white/gray button area)
     */
    private hasSkipButtonPattern;
    /**
     * Check if detections contain ad indicators
     */
    private hasAdIndicators;
    /**
     * Calculate overall confidence score
     */
    private calculateConfidence;
    /**
     * Create canvas from ImageData
     */
    private createCanvasFromImageData;
    /**
     * Get statistics
     */
    getStats(): {
        analysisCount: number;
        adsDetected: number;
        modelLoaded: boolean;
        detectionRate: number;
    };
}
export declare class FrameSampler {
    private video;
    private canvas;
    private ctx;
    private isRunning;
    private samplingInterval;
    private minInterval;
    private maxInterval;
    private lastFrameTime;
    private consecutiveNoAds;
    private visualCortex;
    private onAdDetected;
    constructor(visualCortex: VisualCortex);
    /**
     * Attach to a video element and start sampling
     */
    attachToVideo(video: HTMLVideoElement, onAdDetected?: (result: AnalysisResult) => void): void;
    /**
     * Start adaptive frame sampling
     */
    start(): void;
    /**
     * Stop sampling
     */
    stop(): void;
    /**
     * Main sampling loop with adaptive interval
     */
    private sampleLoop;
    /**
     * Capture current frame and analyze
     */
    private captureAndAnalyze;
    /**
     * Adjust sampling interval based on detection results
     */
    private adjustInterval;
    /**
     * Get current stats
     */
    getStats(): {
        analysisCount: number;
        adsDetected: number;
        modelLoaded: boolean;
        detectionRate: number;
        isRunning: boolean;
        currentInterval: number;
    };
}
export {};
