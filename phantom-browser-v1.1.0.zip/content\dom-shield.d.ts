/**
 * Phantom Browser - DomShield Module
 * Advanced DOM-based ad blocking with Shadow DOM piercing
 *
 * Features:
 * - Advanced MutationObserver for dynamic ad injection
 * - Shadow DOM piercing via attachShadow hook
 * - Pixel stuffing & clickjacking detection (AdAssassin)
 * - Anti-adblock defusal logic
 * - Integrated Overlay/Scam detection
 */
export declare class DomShield {
    private observer;
    private shadowRoots;
    private blockedCount;
    private isEnabled;
    private styleElement;
    private randomId;
    constructor();
    /**
     * Generate a random 8-character ID for stealth
     */
    private generateRandomId;
    /**
     * Get the current stealth ID (for cross-world communication)
     */
    getStealthId(): string;
    private injectStyles;
    /**
     * Start MutationObserver with optimized configuration
     */
    private startObserver;
    /**
     * Handle DOM mutations efficiently
     */
    private handleMutations;
    /**
     * Scan an element and its descendants for ads
     */
    private scanElement;
    /**
     * Check if an element should be blocked
     */
    private checkElement;
    /**
     * Smart Heuristic: Determine if an element is likely part of the site's functionality
     */
    private isLikelyFunctional;
    /**
     * Check for suspicious ad patterns
     * Returns the match type or false if clean
     */
    private hasSuspiciousPatterns;
    private isAdOverlaySelector;
    /**
     * Hide an element
     */
    hideElement(element: Element, reason: string): void;
    /**
     * Mark an element as uncertain (Software Block)
     * This triggers a UI prompt from injected.ts
     */
    softHideElement(element: Element, reason: string): void;
    /**
     * Notify background script of block
     */
    private notifyBlocked;
    /**
     * Add a shadow root for piercing
     */
    addShadowRoot(host: Element, root: ShadowRoot): void;
    /**
     * Get blocked count
     */
    getBlockedCount(): number;
    /**
     * Toggle shield on/off
     */
    setEnabled(enabled: boolean): void;
}
export declare class ShadowPiercer {
    private originalAttachShadow;
    private domShield;
    private piercedRoots;
    constructor(domShield: DomShield);
    /**
     * Hook Element.prototype.attachShadow to capture new shadow roots
     */
    private hookAttachShadow;
    /**
     * Register a shadow root for scanning
     */
    private registerShadowRoot;
    /**
     * Scan for existing shadow roots
     */
    private scanExistingShadowRoots;
    /**
     * Restore original attachShadow (for cleanup)
     */
    restore(): void;
}
export declare class AdAssassin {
    private scanInterval;
    private domShield;
    constructor(domShield: DomShield);
    /**
     * Start periodic scanning for ad fraud techniques
     */
    private startScanning;
    /**
     * Run all detection heuristics
     */
    private runFullScan;
    /**
     * Detect and remove 1x1 pixel tracking iframes
     */
    private detectPixelStuffing;
    /**
     * Detect and remove clickjacking attempts (opacity 0 overlays)
     */
    private detectClickjacking;
    /**
     * Detect stacked ads (multiple ads on top of each other)
     */
    private detectAdStacking;
    /**
     * Check if URL is ad-related
     */
    private isAdRelatedUrl;
    /**
     * Check if element covers significant viewport
     */
    private coversViewport;
    /**
     * Check if two elements overlap
     */
    private elementsOverlap;
    /**
     * Notify background of block
     */
    private notifyBlocked;
    /**
     * Stop scanning
     */
    stop(): void;
}
export declare class AntiAdblockDefuser {
    private observer;
    private originalOverflow;
    constructor();
    /**
     * Monitor for anti-adblock modals and overlays
     */
    private monitorAntiAdblock;
    /**
     * Check if element is an anti-adblock modal
     */
    private checkForAntiAdblock;
    /**
     * Periodically check for persistent loading overlays
     */
    private startLoaderCleanup;
    private cleanupLoaders;
    /**
     * Hook to prevent scroll blocking
     */
    private hookScrollBlocking;
    /**
     * Reset body overflow to allow scrolling
     */
    private resetBodyOverflow;
    /**
     * Check if element covers viewport
     */
    private coversViewport;
    /**
     * Notify background of block
     */
    private notifyBlocked;
    /**
     * Stop monitoring
     */
    stop(): void;
}
