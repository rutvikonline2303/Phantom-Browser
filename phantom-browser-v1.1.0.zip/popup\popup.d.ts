/**
 * Phantom Ad Blocker - Popup Logic
 */
interface Stats {
    adsBlocked: number;
    trackersBlocked: number;
    bandwidthSaved: number;
}
interface PopupState {
    enabled: boolean;
    whitelisted: boolean;
    currentDomain: string;
    stats: Stats;
    moduleStates: Record<string, boolean>;
}
declare const state: PopupState;
declare const masterToggle: HTMLInputElement;
declare const whitelistBtn: HTMLElement;
declare const statusText: HTMLElement;
declare const currentSiteLabel: HTMLElement;
declare const adsBlockedEl: HTMLElement;
declare const trackersBlockedEl: HTMLElement;
declare const timeSavedEl: HTMLElement;
declare const settingsBtn: HTMLElement;
declare const settingsModal: HTMLElement;
declare const closeSettingsBtn: HTMLElement;
declare const moduleToggles: NodeListOf<HTMLInputElement>;
declare function init(): Promise<void>;
declare function updateUI(): void;
declare function saveState(): Promise<void>;
declare function reloadTab(): Promise<void>;
declare function formatNumber(num: number): string;
declare function formatTime(seconds: number): string;
declare function updateIcon(enabled: boolean): void;
