/**
 * Phantom Browser - Offscreen Document Manager
 * Just-in-time creation and lifecycle management of offscreen document
 */
export declare class OffscreenManager {
    private static OFFSCREEN_URL;
    private static IDLE_TIMEOUT_MS;
    private idleTimer;
    private documentCreating;
    /**
     * Ensure offscreen document exists, creating if necessary
     */
    ensureDocument(): Promise<void>;
    /**
     * Check if offscreen document exists using try-catch for API compatibility
     */
    private hasDocument;
    /**
     * Create offscreen document
     */
    private createDocument;
    /**
     * Close offscreen document
     */
    closeDocument(): Promise<void>;
    /**
     * Reset idle timer - document will be closed after 5 minutes of inactivity
     */
    private resetIdleTimer;
    /**
     * Send message to offscreen document
     */
    sendMessage(action: string, data: unknown): Promise<unknown>;
}
