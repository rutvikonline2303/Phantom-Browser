/**
 * Phantom Browser - State Manager
 * Persistent state management for ephemeral Service Worker
 */
import type { ExtensionState, ModuleStates } from '../shared/types';
export declare class StateManager {
    private static STORAGE_KEY;
    /**
     * Initialize default state on first install
     */
    initializeState(): Promise<void>;
    /**
     * Restore state on browser startup (cold-start recovery)
     */
    restoreState(): Promise<ExtensionState>;
    /**
     * Get current state from storage
     */
    getState(): Promise<ExtensionState | null>;
    /**
     * Save state to storage
     */
    private saveState;
    /**
     * Increment blocked count (called on every block)
     */
    incrementBlockedCount(): Promise<void>;
    /**
     * Update whitelist domains
     */
    updateWhitelist(domain: string, add: boolean): Promise<void>;
    /**
     * Toggle module state
     */
    toggleModule(module: keyof ModuleStates, enabled: boolean): Promise<void>;
    /**
     * Get statistics for popup display
     */
    getStats(): Promise<{
        blocked: number;
        trackers: number;
        dataSaved: number;
    }>;
    /**
     * Check if domain is whitelisted
     */
    isWhitelisted(domain: string): Promise<boolean>;
}
