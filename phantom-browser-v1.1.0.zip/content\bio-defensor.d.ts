/**
 * Phantom Browser - BioDefensor Module
 * Audio sentinel for ultrasonic beacon detection and cross-device tracking prevention
 *
 * Phase 4 - Week 16:
 * - AudioContext hooking
 * - FFT analysis for ultrasonic frequencies (18-22kHz)
 * - Beacon scrambling
 */
interface AudioStats {
    contextsMonitored: number;
    beaconsDetected: number;
    beaconsScrambled: number;
    analysisCount: number;
    lastBeaconTime: number | null;
}
export declare class BioDefensor {
    private monitoredContexts;
    private stats;
    private analysers;
    private isScrambling;
    constructor();
    /**
     * Hook AudioContext to monitor all audio streams
     */
    private hookAudioContext;
    /**
     * Monitor an AudioContext for beacon detection
     */
    private monitorContext;
    /**
     * Hook analyser to scramble ultrasonic frequency data
     */
    private hookAnalyser;
    /**
     * Start periodic frequency analysis
     */
    private startAnalysis;
    /**
     * Analyze frequency data for ultrasonic beacons
     */
    private analyzeFrequencyData;
    /**
     * Calculate confidence that a frequency is a tracking beacon
     */
    private calculateBeaconConfidence;
    /**
     * Scramble ultrasonic frequency bins (Uint8Array)
     */
    private scrambleUltrasonicBins;
    /**
     * Scramble ultrasonic frequency bins (Float32Array)
     */
    private scrambleUltrasonicBinsFloat;
    /**
     * Enable/disable scrambling
     */
    setScrambling(enabled: boolean): void;
    /**
     * Get statistics
     */
    getStats(): AudioStats;
    /**
     * Reset statistics
     */
    resetStats(): void;
}
export declare class HardwareProtection {
    private blockedAPIs;
    constructor();
    /**
     * Block Web Bluetooth API
     */
    private blockBluetoothAPI;
    /**
     * Block WebUSB API
     */
    private blockUSBAPI;
    /**
     * Block Web MIDI API
     */
    private blockMIDIAPI;
    /**
     * Block Web Serial API
     */
    private blockSerialAPI;
    /**
     * Get blocked API statistics
     */
    getStats(): {
        bluetooth: number;
        usb: number;
        midi: number;
        serial: number;
    };
}
export {};
