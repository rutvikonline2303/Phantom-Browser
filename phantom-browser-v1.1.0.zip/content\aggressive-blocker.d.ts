/**
 * Phantom Browser - Balanced Ad Blocker
 * Blocks ads without breaking legitimate site content
 */
