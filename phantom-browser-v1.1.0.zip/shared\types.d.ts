/**
 * Phantom Browser - Shared Type Definitions
 * Central type definitions for inter-module communication
 */
export type MessageAction = 'KEEP_ALIVE' | 'BLOCKED_COUNT' | 'UPDATE_DNR_RULE' | 'WHITELIST_SITE' | 'BLOCK_DOMAIN' | 'GET_WHITELISTED_DOMAINS' | 'CHECK_WHITELIST' | 'ANALYZE_MANIFEST' | 'DETECT_SPONSORSHIP' | 'ANALYZE_PHISHING' | 'GET_STATS' | 'GET_NETWORK_GUARD_STATS' | 'GET_TOP_RULES' | 'RESOLVE_CNAME' | 'GET_CNAME_STATS' | 'GET_DETECTED_TRACKERS' | 'SCAN_SUBDOMAINS';
export interface PhantomMessage {
    action: MessageAction;
    payload?: Record<string, unknown>;
}
export interface BlockedCountMessage extends PhantomMessage {
    action: 'BLOCKED_COUNT';
    payload: {
        count: number;
        ruleId?: number;
    };
}
export interface WhitelistMessage extends PhantomMessage {
    action: 'WHITELIST_SITE';
    payload: {
        domain: string;
        enabled: boolean;
    };
}
export interface BlockDomainMessage extends PhantomMessage {
    action: 'BLOCK_DOMAIN';
    payload: {
        domain: string;
        priority?: number;
    };
}
export interface ExtensionState {
    enabled: boolean;
    blockedCount: number;
    trackersBlocked: number;
    dataSaved: number;
    whitelistedDomains: string[];
    moduleStates: ModuleStates;
}
export interface ModuleStates {
    networkGuard: boolean;
    domShield: boolean;
    visualCortex: boolean;
    bioDefensor: boolean;
    web3Guardian: boolean;
}
export interface NetworkGuardStats {
    totalRules: number;
    whitelistRules: number;
    blockRules: number;
    cnameBlocks: number;
    rulesNearLimit: boolean;
    utilizationPercent: number;
}
export interface DynamicRule {
    id: number;
    priority: number;
    action: {
        type: 'block' | 'allow' | 'redirect';
    };
    condition: {
        urlFilter?: string;
        regexFilter?: string;
        resourceTypes?: chrome.declarativeNetRequest.ResourceType[];
        domains?: string[];
        excludedDomains?: string[];
    };
}
export interface CNAMEResolution {
    domain: string;
    resolvedCNAME: string | null;
    isTracker: boolean;
    timestamp: number;
}
export declare const TOP_AD_DOMAINS: string[];
export declare const PROTECTED_DOMAINS: string[];
export declare const SCAM_KEYWORDS: string[];
