/**
 * Phantom Browser - NetworkGuard Module
 * Advanced DNR rule management with 30k limit optimization
 *
 * Features:
 * - Rule priority scoring based on usage
 * - Intelligent LRU-based pruning
 * - Whitelist/blacklist management
 * - Rule deduplication
 * - Session-based hit tracking
 */
import { DNREngine } from './dnr-engine';
interface RuleMetadata {
    id: number;
    domain: string;
    createdAt: number;
    lastHit: number;
    hitCount: number;
    priority: number;
    type: 'block' | 'allow' | 'cname';
}
interface NetworkGuardStats {
    totalRules: number;
    whitelistRules: number;
    blockRules: number;
    cnameBlocks: number;
    rulesNearLimit: boolean;
    utilizationPercent: number;
}
export declare class NetworkGuard {
    private static STORAGE_KEY;
    private static MAX_RULES;
    private static PRUNE_THRESHOLD;
    private static PRUNE_BATCH_SIZE;
    private static WHITELIST_ID_START;
    private static WHITELIST_ID_END;
    private static BLOCK_ID_START;
    private static BLOCK_ID_END;
    private static CNAME_ID_START;
    private dnrEngine;
    private ruleMetadata;
    private domainToRuleId;
    private initialized;
    constructor(dnrEngine: DNREngine);
    initialize(): Promise<void>;
    private loadMetadata;
    private saveMetadata;
    private syncWithDNR;
    /**
     * Add or remove a domain from whitelist
     */
    setWhitelist(domain: string, enabled: boolean): Promise<boolean>;
    /**
     * Check if domain is whitelisted
     */
    isWhitelisted(domain: string): boolean;
    /**
     * Get all whitelisted domains
     */
    getWhitelistedDomains(): string[];
    /**
     * Add a dynamic block rule for a domain
     */
    blockDomain(domain: string, priority?: number): Promise<boolean>;
    /**
     * Block CNAME-uncloaked domain
     */
    blockCNAME(domain: string, resolvedCNAME: string): Promise<boolean>;
    /**
     * Record a hit for a rule (call when rule matches)
     */
    recordHit(ruleId: number): void;
    /**
     * Batch save hit counts (call periodically)
     */
    flushHitCounts(): Promise<void>;
    /**
     * Ensure there's capacity for new rules
     */
    private ensureCapacity;
    /**
     * Prune rules using LRU + hit-count scoring
     */
    private pruneRules;
    /**
     * Calculate rule priority score (higher = more important to keep)
     */
    private calculateRuleScore;
    private normalizeDomain;
    private isProtectedDomain;
    private generateWhitelistId;
    private generateBlockId;
    private generateCNAMEId;
    getStats(): Promise<NetworkGuardStats>;
    /**
     * Get top rules by hit count
     */
    getTopRules(limit?: number): RuleMetadata[];
}
export {};
