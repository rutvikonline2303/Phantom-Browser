/**
 * Phantom Browser - Service Worker Lifecycle Manager
 * Handles SW persistence, state recovery, and graceful degradation
 */
import { StateManager } from './state-manager';
export declare class LifecycleManager {
    private static HEARTBEAT_INTERVAL;
    private heartbeatInterval;
    private stateManager;
    private startTime;
    constructor(stateManager: StateManager);
    /**
     * Initialize lifecycle management
     */
    initialize(): Promise<void>;
    /**
     * Start heartbeat to monitor SW health
     */
    private startHeartbeat;
    /**
     * Set up Chrome alarms for periodic tasks
     * These survive SW restarts
     */
    private setupAlarms;
    /**
     * Handle alarm events
     */
    handleAlarm(alarm: chrome.alarms.Alarm): Promise<void>;
    /**
     * Handle rule update task
     */
    private handleRuleUpdate;
    /**
     * Handle stats sync task
     */
    private handleStatsSync;
    /**
     * Handle cleanup task
     */
    private handleCleanup;
    /**
     * Set up handler for SW termination
     */
    private setupTerminationHandler;
    /**
     * Get SW uptime in seconds
     */
    getUptime(): number;
    /**
     * Check if SW is healthy
     */
    isHealthy(): boolean;
}
