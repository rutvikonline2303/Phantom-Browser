/**
 * Phantom Browser - DNR Engine
 * Declarative Net Request rule management with 30k limit optimization
 */
export declare class DNREngine {
    private static MAX_DYNAMIC_RULES;
    private static RULE_ID_START;
    private currentRuleId;
    private activeRuleIds;
    /**
     * Initialize DNR engine
     */
    initialize(): Promise<void>;
    /**
     * Add a dynamic blocking rule
     */
    addDynamicRule(rule: chrome.declarativeNetRequest.Rule): Promise<boolean>;
    /**
     * Add whitelist rule for domain (allow rule with high priority)
     */
    updateWhitelist(domain: string, whitelist: boolean): Promise<void>;
    /**
     * Block a CNAME-uncloaked domain dynamically
     */
    blockCNAMEDomain(domain: string, resolvedCNAME: string): Promise<void>;
    /**
     * Prune oldest dynamic rules when limit is reached
     */
    private pruneOldestRules;
    /**
     * Generate consistent rule ID for domain (for whitelist rules)
     */
    private hashDomain;
    /**
     * Get next available rule ID for dynamic rules
     */
    private getNextRuleId;
    /**
     * Get current rule count
     */
    getRuleCount(): Promise<{
        static: number;
        dynamic: number;
    }>;
}
