/**
 * Phantom Browser - Wake Lock Manager
 * Keeps Service Worker alive during critical operations
 */
export declare class WakeLockManager {
    private static KEEP_ALIVE_INTERVAL;
    private keepAliveInterval;
    private activeLocks;
    /**
     * Acquire a wake lock for a specific operation
     * @param lockId - Unique identifier for the operation
     */
    acquire(lockId: string): void;
    /**
     * Release a wake lock when operation completes
     * @param lockId - Unique identifier for the operation
     */
    release(lockId: string): void;
    /**
     * Start the keep-alive ping loop
     */
    private startKeepAlive;
    /**
     * Stop the keep-alive ping loop
     */
    private stopKeepAlive;
    /**
     * Execute an async operation with wake lock protection
     */
    withLock<T>(lockId: string, operation: () => Promise<T>): Promise<T>;
    /**
     * Check if any locks are active
     */
    isActive(): boolean;
    /**
     * Get current active lock count
     */
    getLockCount(): number;
}
export declare const wakeLock: WakeLockManager;
