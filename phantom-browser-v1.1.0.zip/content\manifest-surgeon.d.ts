/**
 * Phantom Browser - Manifest Surgeon Module
 * Server-Side Ad Insertion (SSAI) neutralization for HLS/DASH streams
 *
 * Phase 3 - Weeks 9-12:
 * - Week 9: Fetch interception for .m3u8 and .mpd requests
 * - Week 10: HLS parser with #EXT-X-DISCONTINUITY detection
 * - Week 11: DASH parser with Period duration analysis
 * - Week 12: Stitching engine for valid sequence numbers
 */
interface HLSSegment {
    uri: string;
    duration: number;
    discontinuity: boolean;
    isAd: boolean;
    sequence: number;
}
interface HLSManifest {
    version: number;
    targetDuration: number;
    mediaSequence: number;
    segments: HLSSegment[];
    endlist: boolean;
    type?: 'VOD' | 'EVENT' | 'LIVE';
}
interface DASHPeriod {
    id: string;
    start: number;
    duration: number;
    isAd: boolean;
    adaptationSets: DASHAdaptationSet[];
}
interface DASHAdaptationSet {
    mimeType: string;
    representations: DASHRepresentation[];
}
interface DASHRepresentation {
    id: string;
    bandwidth: number;
    baseURL?: string;
    segmentTemplate?: {
        media: string;
        initialization?: string;
        timescale: number;
        duration: number;
    };
}
interface DASHManifest {
    minBufferTime: number;
    mediaPresentationDuration: number;
    periods: DASHPeriod[];
}
interface ManifestStats {
    originalSegments: number;
    removedSegments: number;
    originalDuration: number;
    cleanDuration: number;
    adBlocksDetected: number;
}
export declare class HLSParser {
    /**
     * Parse an HLS manifest (.m3u8) into a structured object
     */
    parse(content: string): HLSManifest;
    /**
     * Check if a segment URL is an ad
     */
    private isAdSegment;
    /**
     * Detect ad blocks based on discontinuity patterns
     * Ads typically appear as: DISCONTINUITY -> ad segments -> DISCONTINUITY
     */
    detectAdBlocks(manifest: HLSManifest): number[];
    /**
     * Heuristic: Does this section look like an ad block?
     */
    private looksLikeAdBlock;
    /**
     * Remove ad segments and rebuild manifest - Week 12
     */
    removeAds(manifest: HLSManifest): {
        manifest: HLSManifest;
        stats: ManifestStats;
    };
    /**
     * Serialize manifest back to .m3u8 format
     */
    serialize(manifest: HLSManifest): string;
}
export declare class DASHParser {
    /**
     * Parse a DASH manifest (.mpd) XML into structured object
     */
    parse(content: string): DASHManifest;
    /**
     * Parse ISO 8601 duration (PT1H2M3.4S format)
     */
    private parseDuration;
    /**
     * Format seconds as ISO 8601 duration
     */
    private formatDuration;
    /**
     * Check if a Period element represents an ad
     */
    private isAdPeriod;
    /**
     * Parse AdaptationSets from a Period
     */
    private parseAdaptationSets;
    /**
     * Remove ad periods and rebuild manifest - Week 12
     */
    removeAds(manifest: DASHManifest): {
        manifest: DASHManifest;
        stats: ManifestStats;
    };
    /**
     * Serialize manifest back to MPD XML format
     */
    serialize(manifest: DASHManifest): string;
}
export declare class ManifestSurgeon {
    private hlsParser;
    private dashParser;
    private stats;
    constructor();
    /**
     * Process any manifest (auto-detect format)
     */
    processManifest(url: string, content: string): string;
    /**
     * Process HLS manifest
     */
    private processHLS;
    /**
     * Process DASH manifest
     */
    private processDASH;
    /**
     * Check if content is HLS
     */
    private isHLS;
    /**
     * Check if content is DASH
     */
    private isDASH;
    /**
     * Update cumulative stats
     */
    private updateStats;
    /**
     * Get cumulative stats
     */
    getStats(): ManifestStats;
    /**
     * Reset stats
     */
    resetStats(): void;
}
export {};
