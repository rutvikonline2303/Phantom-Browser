/**
 * Phantom Browser - Threat Shield Module
 * Advanced protection against Web3 threats, phishing, and rich media ads
 *
 * Phase 6: Advanced Threat Modules
 * - Web3 wallet drainer protection
 * - Phishing detection AI (heuristic)
 * - WebGL texture replacement (Metaverse ads)
 * - MRAID mock injection (rich media neutralization)
 */
interface TransactionRequest {
    to: string;
    from?: string;
    value?: string;
    data?: string;
    gas?: string;
    gasPrice?: string;
}
interface WalletDrainerResult {
    isDrainer: boolean;
    riskLevel: 'low' | 'medium' | 'high' | 'critical';
    reasons: string[];
    blockedContract?: string;
}
interface PhishingResult {
    isPhishing: boolean;
    score: number;
    indicators: string[];
}
interface ThreatStats {
    drainerAttemptsBlocked: number;
    phishingDetected: number;
    webglTexturesReplaced: number;
    mraidCallsBlocked: number;
}
export declare class Web3DrainerProtection {
    private stats;
    constructor();
    /**
     * Hook window.ethereum to intercept transaction requests
     */
    private hookEthereumProvider;
    /**
     * Analyze a transaction for drainer patterns
     */
    analyzeTransaction(tx: TransactionRequest): WalletDrainerResult;
    /**
     * Analyze signature requests for blind signing attacks
     */
    private analyzeSignatureRequest;
    /**
     * Check if address is a known safe marketplace
     */
    private isKnownSafeMarketplace;
    getStats(): {
        suspiciousContracts: string[];
        transactionsAnalyzed: number;
        drainersBlocked: number;
    };
}
export declare class PhishingDetector {
    private stats;
    private readonly indicators;
    constructor();
    /**
     * Analyze current page for phishing indicators
     */
    analyze(): PhishingResult;
    private checkUrlMisspelling;
    private checkSuspiciousTLD;
    private checkExcessiveSubdomains;
    private checkIPAddress;
    private checkUrgencyWords;
    private checkLoginFormHTTP;
    private checkFakeSecurityBadges;
    private checkWalletConnectPhishing;
    private checkNoSSL;
    private checkHiddenElements;
    getStats(): {
        pagesAnalyzed: number;
        phishingDetected: number;
    };
}
export declare class WebGLAdBlocker {
    private stats;
    private transparentTexture;
    constructor();
    /**
     * Hook WebGL functions to intercept texture uploads
     */
    private hookWebGL;
    private hookTexImage2D;
    /**
     * Check if a texture source is likely an ad
     */
    private isAdTexture;
    /**
     * Create a transparent replacement texture
     */
    private createTransparentTexture;
    getStats(): {
        texturesAnalyzed: number;
        texturesReplaced: number;
    };
}
export declare class MRAIDNeutralizer {
    private stats;
    constructor();
    /**
     * Inject comprehensive MRAID mock
     */
    private injectMock;
    getStats(): {
        callsIntercepted: number;
        expandsPrevented: number;
        videosPrevented: number;
    };
}
export declare class ThreatShield {
    web3Protection: Web3DrainerProtection;
    phishingDetector: PhishingDetector;
    webglBlocker: WebGLAdBlocker;
    mraidNeutralizer: MRAIDNeutralizer;
    constructor();
    private schedulePhishingCheck;
    private showPhishingWarning;
    /**
     * Get combined stats
     */
    getStats(): ThreatStats;
}
export {};
